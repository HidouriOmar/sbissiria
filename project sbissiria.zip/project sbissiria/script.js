// Ajout d'un écouteur d'événement au formulaire
document.getElementById('pharmacy-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Empêche le rechargement de la page

    // Récupération des valeurs des champs
    const country = document.getElementById('country').value;
    const city = document.getElementById('city').value;
    const latitude = document.getElementById('latitude').value;
    const medicine = document.getElementById('medicine').value;

    // Validation simple
    if (!country || !city || !latitude || !medicine) {
        alert('يرجى ملء جميع الحقول.');
        return;
    }

    // Simuler les résultats
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = `
        <h3>نتائج البحث:</h3>
        <ul>
            <li>صيدلية الأمل (الموقع: وسط المدينة) - الدواء متوفر</li>
            <li>صيدلية الشفاء (الموقع: شارع الجامعة) - كمية محدودة</li>
        </ul>
    `;

    // Vous pouvez intégrer ici un appel à une API si nécessaire
    // Exemple : Utilisation de fetch() pour appeler une API
});
